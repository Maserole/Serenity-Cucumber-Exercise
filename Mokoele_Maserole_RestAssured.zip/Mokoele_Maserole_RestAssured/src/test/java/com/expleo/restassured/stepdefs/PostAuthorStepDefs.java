package com.expleo.restassured.stepdefs;

import com.expleo.restassured.steps.AuthorNameByPostID;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class PostAuthorStepDefs {

    String postID;
    String authorName;

    @Steps
    AuthorNameByPostID authorNameByPostID;  //Actor

    @Given("^I use valid post ID$")
    public void iUseValidPostID(){

        //Setting values to variables
        this.postID = "6";
        this.authorName = "Danica";
    }

    @When("^I submit valid post ID$")
    public void iSubmitValidPostID(){

        authorNameByPostID.submitValidPostIDAs(authorName);
    }

    @Then("^I receive the correct author$")
    public void iReceiveTheCorrectAuthor(){

        authorNameByPostID.receiveTheCorrectAuthorAs(postID,authorName);
    }
}
