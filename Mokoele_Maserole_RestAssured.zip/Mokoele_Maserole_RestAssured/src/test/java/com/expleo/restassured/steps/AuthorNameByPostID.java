package com.expleo.restassured.steps;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import net.thucydides.core.annotations.Step;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;


public class AuthorNameByPostID {


    private static RequestSpecification requestSpec;
    private static ResponseSpecification responseSpec;

    @Step("Sending Request and Getting Response")
    public void submitValidPostIDAs(String authorName) {

        setReqSpec();
        setRespSpec(authorName);
    }
    private void setReqSpec() {

        //Request Specification - With Path and Base URI To Access Webservice
        requestSpec = new RequestSpecBuilder()
                .setBaseUri("http://10.9.10.139:3000")
                .setBasePath("/posts/")
                .build();
    }
    private void setRespSpec(String authorName) {

        /*
         *Catching Assertion Error After Checking IF
         *The Provided Author Name Is The Same Pulled From Request
         */

        try{
            responseSpec = new ResponseSpecBuilder()
                    .expectStatusCode(200)
                    .expectBody("author",equalTo(authorName))
                    .build();

        }catch (AssertionError e){

            e.getMessage();
        }

    }


    @Step("The Author Name Is: "+"{1}")
    public void receiveTheCorrectAuthorAs(String id, String authorN) {

        //Retrieving The Request Using post ID
        Response response = given(requestSpec,responseSpec)
                .get(id);
        response.then().log().all();
    }
}
