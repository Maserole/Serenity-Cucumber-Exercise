package com.expleo.qe.Pages;
import net.thucydides.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class BookingFlightObject extends PageObject {

    private WebElement Origin; //For Selecting Origin
    private WebElement Destination; //For Selecting Destination
    private WebElement seat; //Entering The Seat Number
    private WebElement Flightclass; //Selecting The Class
    private WebElement submitbutton; //Submit Button

    @FindBy(how = How.XPATH, using = "/html/body/div/div/div[2]/h2/center")
    private WebElement verifyBookingSuccessful;

    public void selectOrigin() {

        Select myOrigin = new Select(Origin);
        myOrigin.selectByVisibleText("Chicago");
    }

    public void selectDestination() {

        Select myDestination = new Select(Destination);
        myDestination.selectByVisibleText("Johannesburg");
    }

    public void enterSeat(String seatNumber) {

        seat.clear();
        seat.sendKeys(seatNumber);
    }

    public void selectClass() {

        Select myClass = new Select(Flightclass);
        myClass.selectByVisibleText("First");

        try {

            Thread.sleep(3000);
        } catch (InterruptedException e) {

            e.printStackTrace();
        }
    }

    public void clickBookButton() {

        submitbutton.click();
    }

    public void successfulBooking() {

        Assert.assertEquals("Booking Should Be Successful","Flight booked successfully",verifyBookingSuccessful.getText());
    }
}
