package com.expleo.qe.Stepdefinitions;
import com.expleo.qe.Steps.BookingFlightSteps;
import com.expleo.qe.Steps.LoginSteps;
import com.expleo.qe.Steps.NavigationSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;


public class Cloud9StepDefinition {

    @Steps
    LoginSteps loginSteps;

    @Steps
    NavigationSteps navigationSteps;

    @Steps
    BookingFlightSteps bookingFlightSteps;


    @Given("^That I am on the Cloud(\\d+) home page$")
    public void that_I_am_on_the_Cloud_home_page(int arg1) {

        loginSteps.openBrowser();
    }


    @When("^Log in with a valid user email and password$")
    public void log_in_with_a_valid_user_email_and_password() {

        loginSteps.LoginDetails("Maserole.Mokoele@expleogroup.com","M@s3r0l3@1993");
    }

    @Then("^I will be taken to the itinerary page$")
    public void i_will_be_taken_to_the_itinerary_page() {

       navigationSteps.confirmItineraryPage();
    }

    @Given("^I navigate to the booking page$")
    public void i_navigate_to_the_booking_page() {

        navigationSteps.BookFlight();
        navigationSteps.ValidateBookingPage();
    }


    @When("^I add a valid booking$")
    public void i_add_a_valid_booking() {

        bookingFlightSteps.BookingInfo();
    }

    @Then("^My booking is successful$")
    public void my_booking_is_successful() {

        bookingFlightSteps.BookingSuccessful();
        navigationSteps.clickItinerary();
        navigationSteps.confirmItineraryPage();
        navigationSteps.Logout();
    }
}
