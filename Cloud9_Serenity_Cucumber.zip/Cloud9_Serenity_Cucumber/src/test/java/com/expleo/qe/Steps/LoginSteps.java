package com.expleo.qe.Steps;
import com.expleo.qe.Pages.LoginPageObject;
import net.thucydides.core.annotations.Step;

public class LoginSteps {

    LoginPageObject loginPage;

    @Step("Open Browser")
    public void openBrowser(){
        loginPage.OpenTheBrowser();
    }

    @Step("Capture Email Address {0} and Password {1}")
    public void LoginDetails(String email, String password) {

        loginPage.enterEmail(email);
        loginPage.enterPassword(password);

        try {

            Thread.sleep(3000);
            loginPage.clickSignInButton();
        } catch (InterruptedException e) {

            e.printStackTrace();
        }


    }

}
