package com.expleo.qe.Steps;

import com.expleo.qe.Pages.BookingFlightObject;
import net.thucydides.core.annotations.Step;

public class BookingFlightSteps {


    BookingFlightObject bookingFlightObject;

    @Step("Entering Booking Flight Information")
    public void BookingInfo() {

        bookingFlightObject.selectOrigin();
        bookingFlightObject.selectDestination();
        bookingFlightObject.enterSeat("C25");
        bookingFlightObject.selectClass();
        bookingFlightObject.clickBookButton();
    }

    @Step("Verify If Booking Was SuccessFul")
    public void BookingSuccessful() {

        bookingFlightObject.successfulBooking();
    }
}
