package com.expleo.qe.Pages;
import net.thucydides.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class NavigationPageObject extends PageObject {

    @FindBy(how = How.LINK_TEXT, using = "Logout")
    private WebElement logoutLink;

    @FindBy(how = How.LINK_TEXT, using = "Book Flight")
    private WebElement bookingLink;

    @FindBy(how = How.XPATH, using = "/html/body/div/div/div[2]/h1")
    private WebElement bookingPage;

    @FindBy(how = How.LINK_TEXT, using = "Itinerary")
    private WebElement itineraryPage;

    @FindBy(xpath= "/html/body/div/div/div[2]/h1")
    private WebElement itineraryHeader;

    public void clickLogout() {

        logoutLink.click();
    }

    public void clickBookFlight() {
        bookingLink.click();
    }

    public void verifyBookingPage() {

        Assert.assertEquals("Should Be On Booking Flight Page", "Book Flight",bookingPage.getText());
    }

    public void itineraryPage() {

        try {

            Thread.sleep(3000);
        } catch (InterruptedException e) {

            e.printStackTrace();
        }
        itineraryPage.click();
    }
    public void assertItineraryPage() {

        //TODO Refactor XPATH
        //TODO Make Assert Generic
        Assert.assertEquals("Should Be On Itinerary Page.", "Itinerary" ,itineraryHeader.getText());

    }
}
