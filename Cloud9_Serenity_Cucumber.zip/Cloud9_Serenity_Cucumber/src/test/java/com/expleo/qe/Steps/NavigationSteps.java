package com.expleo.qe.Steps;

import com.expleo.qe.Pages.NavigationPageObject;
import net.thucydides.core.annotations.Step;

public class NavigationSteps {

    NavigationPageObject navigationPageObject;

    @Step("Now We Logout")
    public void Logout() {

        navigationPageObject.clickLogout();
    }

    @Step("Navigating To Flight Booking Page By Clicking On Book Flight")
    public void BookFlight() {

        navigationPageObject.clickBookFlight();
    }

    @Step("Validating The Flight Booking Page")
    public void ValidateBookingPage() {

        navigationPageObject.verifyBookingPage();
    }

    @Step("Navigating To Itinerary Page By Clicking On Itinerary")
    public void clickItinerary() {

        navigationPageObject.itineraryPage();
    }
    @Step("Verify If We On Itinerary Page")
    public void confirmItineraryPage() {

        navigationPageObject.assertItineraryPage();
    }
}
