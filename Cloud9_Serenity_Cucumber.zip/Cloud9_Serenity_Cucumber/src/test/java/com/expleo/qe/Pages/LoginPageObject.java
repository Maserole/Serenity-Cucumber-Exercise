package com.expleo.qe.Pages;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.concurrent.TimeUnit;


@DefaultUrl("http://performance-testing.co.za/Main/login.html")
public class LoginPageObject extends PageObject {

    private WebElement inputEmail;
    private WebElement inputPassword;
    private WebElement SigninButton;

    public void OpenTheBrowser(){
        

        
        try {
            open();
            getDriver().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void enterEmail(String email) {
        inputEmail.clear();
        inputEmail.sendKeys(email);
    }

    public void enterPassword(String password) {
        inputPassword.clear();
        inputPassword.sendKeys(password);
    }

    public void clickSignInButton() {
        SigninButton.click();
    }

}

